# Tab Rehab (v0.2)

Help for chronic tab hoarders. A Chrome extension (it also works in Edge, Brave and Arc).

## Install (2 minutes)
1. Unzip `tab-rehab.zip` into a folder you'll keep, for example `~/Apps/tab-rehab`.
2. Open `chrome://extensions` and turn on **Developer mode** (top right).
3. Click **Load unpacked** and choose the folder.
4. Pin the icon. Click it, or press **Alt+Shift+T**, to open the dashboard.

## What it does
- **Badge**: your live tab count. Green under 30, amber under 100, red above.
- **Open tabs**: every tab from every window, grouped by site or window. Search with `/`. Select several, then Park, To-do, Snooze or Close.
- **Rehab session**: one tab at a time, oldest first. Keys: **K**eep, **T**o-do, **S**nooze, **B**ookmark, **P**ark, **C**lose, **O** to peek.
- **Stale**: tabs you haven't opened in N days. Park them all with one click.
- **Quick wins**: duplicates, empty tabs, old search results and error pages. Close them with no risk.
- **Parked & snoozed**: saved lists you can restore one tab at a time or all together. Restored tabs go back to the window they came from, or to a new window if that one has been closed. Snoozed tabs reopen by themselves. "Recently closed" is your safety net.
- **To-dos**: turn a "don't forget" tab into a note, link and reminder (a Chrome notification).
- **Bookmarks** (★): save a tab, a group, a selection or a whole parked list into a bookmarks folder (default: "Tab Rehab" in Other bookmarks), and optionally close the tabs. In Rehab sessions press **B**.
- **Safety**: confirmation before parking more than 10 tabs; Undo stays on screen for 15 seconds.
- **Right-click** any page: "Save this tab as a to-do" or "Park this tab".
- **Daily nudge** when 5 or more tabs are stale. **Health trend** in the sidebar.
- **Export/Import backup** (JSON). Everything stays on your computer: no account, no servers, no tracking.

## Updating
Replace the files in the folder, then click the reload arrow on the card in `chrome://extensions`. Your data stays.
